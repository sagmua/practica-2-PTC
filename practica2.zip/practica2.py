# -*- coding: utf-8 -*-
"""
Created on Tue Jan 16 17:12:00 2018

@author: samuel
"""


from test import Test #La clase de nuestro examen
from tkinter import * #Para la interfaz
from math import *


if __name__ == "__main__":
    
    
    t = Test()
    