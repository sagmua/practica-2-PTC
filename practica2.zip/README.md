# practica-2-PTC

Para la utilización de la práctica:

## Generar test
Si deseamos 
generar un test, basta con ejecutar nuestro archivo 'generar_test.py',
he ir añadiendo las preguntas de la siguiente forma:
	- escribimos la pregunta
	- escribimos la respuesta y su valoración, y la pulsamos añadir respuesta (repetimos con todas las posibles respuestas)
	- Pulsamos el boton añadir pregunta y repetimos para las demás preguntas
	- Para finalizar, escribimos el nombre del examen, y pulsamos Generar.

##Realizar test
Para la realización de un test, basta con ejecutar el archivo 'realizar_test.py'.
Para la realización elegimos un test de los disponibles y resopndemos hasta finalizar.


##Corregir tests
Para corregir los test y obtener la gráfica con las notas de todos los test corregidos 
basta con ejecutar 'corregir.py'